import crypto from 'node:crypto'

function key() {
  const raw = process.env.COUNSELLOR_NOTES_ENCRYPTION_KEY
  if (!raw) throw new Error('COUNSELLOR_NOTES_ENCRYPTION_KEY is not configured')
  const buf = Buffer.from(raw, 'base64')
  if (buf.length !== 32) throw new Error('COUNSELLOR_NOTES_ENCRYPTION_KEY must decode to exactly 32 bytes')
  return buf
}

export function encryptText(plaintext: string) {
  const iv = crypto.randomBytes(12)
  const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv)
  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()])
  const authTag = cipher.getAuthTag()
  return { ciphertext: ciphertext.toString('base64'), iv: iv.toString('base64'), authTag: authTag.toString('base64') }
}

export function decryptText(ciphertext: string, iv: string, authTag: string) {
  const decipher = crypto.createDecipheriv('aes-256-gcm', key(), Buffer.from(iv, 'base64'))
  decipher.setAuthTag(Buffer.from(authTag, 'base64'))
  return Buffer.concat([decipher.update(Buffer.from(ciphertext, 'base64')), decipher.final()]).toString('utf8')
}
